<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @package louis
 */
get_header();
?>

<div class="insideposts">
	<div class="wrapper">
		<?php
		get_template_part( 'inc/partials/content', 'none' );
		?>
		
	</div></div>
<?php get_footer();
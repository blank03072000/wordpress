<template>
    <div class="page-500">
        <div class="justify-content-center">

                <div class="clearfix">
                    <div class="col-sm-4">
                        <h1 class="float-left display-3 mr-4">500</h1>
                    </div>
                    <div class="col-sm-8">
                    <h5 class="pt-3">Houston, we have a problem!</h5>
                    <p class="text-muted text-small">The page you are looking for was not found.</p>
                    </div>


                </div>
                <div class="input-prepend input-group">
                    <span class="input-group-addon"><i class="fa fa-search"></i></span>
                    <input id="prependedInput" class="form-control" size="16" type="text" placeholder="What are you looking for?">
                    <span class="input-group-btn">
                        <button class="btn btn-info" type="button">Search</button>
                    </span>
                </div>

        </div>
    </div>
</template>
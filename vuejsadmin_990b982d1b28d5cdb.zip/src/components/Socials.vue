<template>
  	<div class="animated fadeIn social-buttons row">

		<div class="col-md-6">
	        <div class="card">
	            <div class="card-header">
	                <strong>Social Buttons <small>(Rounded)</small> </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body social">

					<a href="#" class="social__button mail"><i class="fa fa-envelope-o"></i></a>
					<a href="#" class="social__button facebook"><i class="fa fa-facebook"></i></a>
					<a href="#" class="social__button linkedin"><i class="fa fa-linkedin"></i></a>
					<a href="#" class="social__button github"><i class="fa fa-github"></i></a>
					<a href="#" class="social__button codepen"><i class="fa fa-codepen"></i></a>
				
	            </div>
	        </div>
		</div>



		<div class="col-md-6">
	        <div class="card" id="social-square">
	            <div class="card-header">
	                <strong>Social Buttons <small>(Square)</small> </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body social-square">
					
					<ul class="social">
					  	<li><i class="fa fa-facebook" aria-hidden="true"></i></li>
					  	<li><i class="fa fa-twitter" aria-hidden="true"></i></li>
						<li><i class="fa fa-instagram" aria-hidden="true"></i></li>
						<li><i class="fa fa-vimeo" aria-hidden="true"></i></li>
						<li><i class="fa fa-behance" aria-hidden="true"></i></li>
						<li><i class="fa fa-dribbble" aria-hidden="true"></i></li>
						<li><i class="fa fa-github" aria-hidden="true"></i></li>
						<li><i class="fa fa-pied-piper" aria-hidden="true"></i></li>
					</ul>
				
	            </div>
	        </div>
		</div>





		<div class="col-md-6">
	        <div class="card" id="social-aeneas">
	            <div class="card-header">
	                <strong>Aeneas Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect aeneas">
				
					<div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				    <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
					</div>
				
	            </div>
	        </div>
		</div>



		<div class="col-md-6">
	        <div class="card" id="social-jaques">
	            <div class="card-header">
	                <strong>Jaques Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect jaques">

				    <div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				    <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				    </div>
				
	            </div>
	        </div>
		</div>



		<div class="col-md-6">
	        <div class="card" id="social-egeon">
	            <div class="card-header">
	                <strong>Egeon Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect egeon">

				    <div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				      <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				    </div>
				
	            </div>
	        </div>
		</div>





		<div class="col-md-6">
	        <div class="card" id="social-claudio">
	            <div class="card-header">
	                <strong>Claudio Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect claudio">

				    <div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				      <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				    </div>
				
	            </div>
	        </div>
		</div>




		<div class="col-md-6">
	        <div class="card" id="social-laertes">
	            <div class="card-header">
	                <strong>Claudio Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect laertes">

				    <div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				      <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				    </div>
				
	            </div>
	        </div>
		</div>



		<div class="col-md-6">
	        <div class="card" id="social-jinae">
	            <div class="card-header">
	                <strong>Jinae Effect </strong>
	                <div class="card-actions">
	                    <a href="#" class="btn-setting"><i class="fa fa-cog"></i></a>
	                    <button class="btn-minimize" type="button" data-toggle="collapse" data-target="" aria-expanded="false" aria-controls="collapseExample">
	                        <i class="fa fa-angle-down"></i>
	                    </button>
	                    <a href="#" class="btn-close"><i class="fa fa-times"></i></a>
	                </div>
	            </div>
	            <div class="card-body effect jinae">

				    <div class="buttons">
				      <a href="#" class="fb" title="Join us on Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a>
				      <a href="#" class="tw" title="Join us on Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a>
				      <a href="#" class="g-plus" title="Join us on Google+"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
				      <a href="#" class="dribbble" title="Join us on Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a>
				      <a href="#" class="vimeo" title="Join us on Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a>
				      <a href="#" class="pinterest" title="Join us on Pinterest"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
				      <a href="#" class="insta" title="Join us on Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a>
				      <a href="#" class="in" title="Join us on Linked In"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
				    </div>
				
	            </div>
	        </div>
		</div>



	</div>
</template>	

<style lang="scss" scoped>
	/* Variables */
	$basic-dark-color: #ddd;
	$basic-light-color: #fff;
	$fb-color: #3b5998;
	$tw-color: #00aced;
	$g-plus: #dd4b39;
	$dribbble: #ea4c89;
	$pinterest: #cb2027;
	$insta: #bc2a8d;
	$in: #007bb6;
	$vimeo: #1ab7ea;
	$border-radius: 10px;
	$font-size: 25px;

	$radius: 75px;
	$color: #000;
	$bg: #fff;

	$colors: (
	  "mail": #0072C6,
	  "facebook": #3b5999,
	  "linkedin": #0077b5,
	  "github": #6e5494,
	  "codepen": #212121
	);

	.social-buttons .social, .social-square{
		background-color: $basic-dark-color;
	}
	.social {
	  display: flex;
	  justify-content: center;
	  flex-wrap: wrap;

	  &__button {
	    display: block;
	    width: $radius;
	    height: $radius;
	    border-radius: 100%;
	    background: $bg;
	    position: relative;
	    cursor: pointer;
	    margin: 5px;
	    text-align: center;

	    i {
	      display: inline-block;
	      position: absolute;
	      left: 0;
	      top: 0;
	      height: $radius;
	      line-height: $radius;
	      width: $radius;
	      font-size: $radius / 2;
	      color: $color;
	      z-index: 2;
	      transition: 0.3s;
	    }

	    &:after {
	      content: '';
	      display: block;
	      position: absolute;
	      background: $color;
	      border-radius: 100%;
	      width: 0;
	      height: 0;
	      transition: 0.3s;
	      top: 0;
	      left: 50%;
	    }

	    &:hover i {
	      color: $bg;
	    }

	    &:hover:after {
	      width: $radius;
	      height: $radius;
	      margin-left: -1 * $radius / 2;
	    }
	  }
	}

	@each $name, $color in $colors {
	  .#{$name} {
	    i {
	      color: $color;
	    }
	    &:after {
	      background: $color;
	    }
	  }
	}


	#social-square {
	  .social {
	    padding-left: 0px;
	  }
	  li {
	    list-style-type: none;
	    display: inline-block;
	    width: 50px;
	    height: 50px;
	    line-height: 50px;
	    padding: 1%;
	    border: 1px solid #212121;
	    cursor: pointer;
	    margin-left: 10px;
	    margin-top: 20px;
	    transition: ease .3s;
	    i{
	    	padding: 0;
		    padding: 0px 0 0 8px;
		    font-size: 25px;
	    }
	    &:hover {
	      color: #212121;
	      border: 1px solid #212121;
	    }
	  }
	}

	.social:hover > li {
	  opacity: 0.5;
	}

	.social:hover > li:hover {
	  opacity: 1;
	}


	/* Effect Socials */

	.effect {
	  background-color: $basic-dark-color;

	  &:nth-child(2n+1) {
	    background-color: $basic-light-color;
	    
	    h2 {
	      color: $basic-dark-color;
	    }
	  }
	  
	  .buttons {
	    display: flex;
	    justify-content: center;
	  }
	  
	  a {
	    
	    &:last-child {
	      margin-right: 0px;
	    }
	  }
	}

	/*common link styles !!!YOU NEED THEM*/
	.effect {
	  /*display: flex; !!!uncomment this line !!!*/
	  
	  a {
	    text-decoration: none !important;
	    color: $basic-light-color;
	    width: 60px;
	    height: 60px;
	    display: flex;
	    align-items: center;
	    justify-content: center;
	    border-radius: $border-radius;
	    margin-right: 10px;
	    font-size: $font-size;
	    overflow: hidden;
	    position: relative;
	    
	    i {
	      position: relative;
	      z-index: 3;
	    }
	    
	    &.fb {
	      background-color: $fb-color;
	    }
	    
	    &.tw {
	      background-color: $tw-color;
	    }
	    
	    &.g-plus {
	      background-color: $g-plus;
	    }
	    
	    &.dribbble {
	      background-color: $dribbble;
	    }
	    
	    &.pinterest {
	      background-color: $pinterest;
	    }
	    
	    &.insta {
	      background-color: $insta;
	    }
	    
	    &.in {
	      background-color: $in;
	    }
	    
	    &.vimeo {
	      background-color: $vimeo;
	    }
	  }
	}

	

	/* aeneas effect */

	.effect.aeneas {
	  
	  a {
	    transition: transform 0.4s linear 0s, border-top-left-radius 0.1s linear 0s, border-top-right-radius 0.1s linear 0.1s, border-bottom-right-radius 0.1s linear 0.2s, border-bottom-left-radius 0.1s linear 0.3s;
	    
	    i {
	      transition: transform 0.4s linear 0s;
	    }
	    
	    &:hover {
	      transform: rotate(360deg);
	      border-radius: 50%;
	      
	      i {
	        transform: rotate(-360deg);
	      }
	    }
	  }
	}


	/* jaques effect */
	.effect.jaques {
	  
	  a {
	    transition: border-top-left-radius 0.1s linear 0s, border-top-right-radius 0.1s linear 0.1s, border-bottom-right-radius 0.1s linear 0.2s, border-bottom-left-radius 0.1s linear 0.3s;
	    
	    &:hover {
	      border-radius: 50%;
	    }
	  }
	}


	/* egeon effect */
	.effect.egeon {
	  a {
	    transition: transform 0.2s linear 0s, border-radius 0.2s linear 0.2s;
	    
	    i {
	      transition: transform 0.2s linear 0s;
	    }
	    
	    &:hover {
	      transform: rotate(-90deg);
	      border-top-left-radius: 50%;
	      border-top-right-radius: 50%;
	      border-bottom-left-radius: 50%;
	      
	      i {
	        transform: rotate(90deg);
	      }
	    }
	  }
	}

	/* egeon claudio */
	.effect.claudio {
	  a { 
	    transition: transform 0.2s linear 0s, border-radius 0.2s linear 0s;
	    
	    &:hover {
	      transform: scale(1.2);
	      border-bottom-left-radius: 50%;
	      border-top-right-radius: 50%;
	    }
	  }
	}



	/* jinae effect */
	.effect.jinae {
	  a { 
	    transition: transform 0.2s linear 0s, border-radius 0.2s linear 0s;
	    
	    &:hover {
	      transform: scale(1.2);
	      border-bottom-right-radius: 50%;
	      border-top-left-radius: 50%;
	    }
	  }
	}



	/* laertes effect */
	.effect.laertes {
	  a {
	    transition: all 0.2s linear 0s;
	    
	    i {
	      transition: all 0.2s linear 0s;
	    }
	   
	    &:hover {
	      border-radius: 50%/20%;
	      
	      i {
	        transform: scale(1.1);
	        text-shadow: 0 0 12px rgba($basic-dark-color, 0.6);
	      }
	    }
	  }
	}



</style>
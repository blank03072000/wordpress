<?php
/**
 * The template for displaying the footer
 */
?>
    </div>
    <?php
    /**
     * Footer include section
     */
    $subscribe_layout = 'disabled';
    if ( function_exists( 'FW' ) ) {

        $subscribe_layout = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'subscribe-layout' );
    }
        add_filter( 'body_class', 'acidum_subscribe_body_class', 10 );
        function acidum_subscribe_body_class( $classes ) { 

            $classes[] = 'subscribe-enabled';
            return $classes;         
        }
    $subscribe_section = get_page_by_path( 'subscribe', OBJECT, 'sections' );
    if ( !empty($subscribe_section) AND !empty($subscribe_layout) AND $subscribe_layout != 'disabled' ) echo '<div class="container subscribe-block">'.do_shortcode(wp_kses_post($subscribe_section->post_content)).'</div>';


    ?>
    <?php
    /**
    	Footer customization
    */
    $footer_layout = 'visible';
    if ( function_exists( 'FW' ) ) {

        $footer_layout = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'footer-layout' );
    }

    if ( function_exists( 'FW' ) AND $footer_layout != 'disabled') {

    	/* Counting active cols number */
    	$footer_cols_num = 0;
    	for ($x = 1; $x <= 4; $x++) {

    		if ( !fw_get_db_settings_option( 'footer_' . $x . '_hide' ) ) {

    			$footer_cols_num++;
    		}
    	}
    }                
    	else {

        $footer_cols_num = 0;
   	}    	
	?>	
	<?php if ( $footer_cols_num > 0): ?>
	<div id="block-footer">
		<div class="container">
			<div class="row">
                <?php
                /* By default columns with different layout */
                $footer_tmpl = array(
                	4	=>	array(
                			'col-md-2 col-sm-6 col-ms-12',
                			'col-md-4 col-sm-6 col-ms-12',
                			'col-md-3 col-sm-6 col-ms-12',
                			'col-md-3 col-sm-6 col-ms-12',
                		),
                	3	=>	array(
                			'col-md-4 col-sm-6 col-ms-12',
                			'col-md-4 col-sm-6 col-ms-12',
                			'col-md-4 col-sm-6 col-ms-12',
                			'col-md-4 col-sm-6 col-ms-12',
                		),
                	2	=>	array(
                			'col-md-6 col-sm-12',
                			'col-md-6 col-sm-12',
                			'col-md-6 col-sm-12',
                			'col-md-6 col-sm-12',
                		),
                	1	=>	array(
                			'col-md-12',
                			'col-md-12',
                			'col-md-12',
                			'col-md-12',
                		),
                );

               	$footer_hide = array();
                if ( function_exists( 'fw_get_db_settings_option' ) ) {

                	/* Counting active cols number */
                	$footer_cols_num = 0;
                	for ($x = 1; $x <= 4; $x++) {

                		if ( !fw_get_db_settings_option( 'footer_' . $x . '_hide' ) ) {

                			$footer_cols_num++;
                		}
                			else {

                			$footer_hide[$x] = true;
                		}
                	}
                }                
                	else {

	                $footer_cols_num = 4;
               	}

                for ($x = 1; $x <= 4; $x++):

                	$class = '';
                	if ( isset($footer_tmpl[$footer_cols_num][( $x - 1 )]) ) {

                		$class = $footer_tmpl[$footer_cols_num][( $x - 1 )];
                	}

                	$col_hide_mobile = '';
                	if ( function_exists( 'fw_get_db_settings_option' ) && fw_get_db_settings_option( 'footer_' . $x . '_hide_mobile') ) {

                		$col_hide_mobile = 'hidden-xs hidden-ms hidden-sm';
                	}

                    $acidum_footer_sidebars_active = 0;
                    ?>
                    <?php if ( !isset($footer_hide[ $x ]) ): ?>
					<div class="<?php echo esc_attr( $class ).' '.esc_attr( $col_hide_mobile ); ?> matchHeight clearfix">    
						<?php if ( is_active_sidebar( 'footer-' . $x ) ) : ?>
							<div class="footer-widget-area">
								<?php
                                    dynamic_sidebar( 'footer-' . $x );
                                    $acidum_footer_sidebars_active++;
                                ?>
							</div>
						<?php else: ?>
							<div class="footer-widget-area">
	                            <h4><?php esc_html__( 'Footer', 'acidum' ); ?> <?php echo esc_html( $x ); ?></h4>
	                            <a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>"><?php echo esc_html__( 'To add your widgets click here', 'acidum' ); ?></a>
	                        </div>
						<?php endif; ?>
					</div>
					<?php endif; ?>
                    <?php
                endfor;
                ?>
			</div>
		</div>
        <?php
        /* Floating image */
        $footer_bg = fw_get_db_settings_option( 'footer_bg' );
        if (! empty( $footer_bg ) ) {

            echo '<img src="'.esc_url( $footer_bg['url'] ) . '" class="float" alt="-" />';
        }
        ?>
	</div><?php endif; ?>
    <?php 
    $copyright_layout = 'default';
    if ( function_exists( 'FW' ) ) {

        $acidum_copyrights = fw_get_db_settings_option( 'copyrights' );
        $acidum_go_top_hide = fw_get_db_settings_option( 'go_top_hide');
        $acidum_go_top_img = fw_get_db_settings_option( 'go_top_img');
        $copyright_layout = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'copyright-layout' );
    }

    if ( $copyright_layout == 'default' OR empty($copyright_layout) ) {

    ?>
	<footer class="footer-block">
		<div class="container">
			<?php if ( !empty($acidum_copyrights) ) : ?>
				<?php echo wp_kses_post( $acidum_copyrights ); ?>
			<?php else : ?>
				<p><?php echo esc_html__( 'Like-themes &copy; All Rights Reserved - 2017', 'acidum' );?></p>
			<?php endif; ?>
			<?php if ( isset($acidum_go_top_hide) AND $acidum_go_top_hide !== true ) : ?>
                <a href="#" class="go-top go-top-text hidden-xs hidden-ms">                    
                    <span></span><?php echo esc_html__( 'go top', 'acidum' );?>
                </a>
			<?php endif; ?>
		</div>
	</footer>
    <?php
    }
    ?>
	<?php wp_footer(); ?>
</body>
</html>

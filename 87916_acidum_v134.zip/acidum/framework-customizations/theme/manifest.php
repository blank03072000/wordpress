<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'acidum';

$manifest['supported_extensions'] = array(
	'backups' => array(),
	'seo' => array(),
	'styling' => array(),
	'megamenu' => array(),
);

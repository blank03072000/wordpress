<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}


$options = array(
	'theme_block' => array(
		'title'   => esc_html__( 'Theme Block', 'acidum' ),
		'label'   => esc_html__( 'Theme Block', 'acidum' ),
		'type'    => 'select',
		'choices' => array(
			'none'  => esc_html__( 'Not Assigned', 'acidum' ),
			'subscribe'  => esc_html__( 'Subscribe', 'acidum' ),			
			'top_bar'  => esc_html__( 'Top Bar', 'acidum' ),
		),
		'value' => 'none',
	)
);



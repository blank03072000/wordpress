<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'main' => array(
		'title'   => false,
		'type'    => 'box',
		'options' => array(
			'cut'    => array(
				'label' => esc_html__( 'Short Description', 'acidum' ),
				'type'  => 'text',
			),
			'duration'    => array(
				'label' => esc_html__( 'Duration', 'acidum' ),
				'type'  => 'text',
				'value'  => '',
			),				
			'price'    => array(
				'label' => esc_html__( 'Price', 'acidum' ),
				'type'  => 'text',
				'value'  => '',
			),		
		),
	),
);


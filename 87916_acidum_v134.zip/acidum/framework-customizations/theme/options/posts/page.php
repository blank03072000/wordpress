<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$acidum_choices =  array();
$acidum_choices['default'] = esc_html__( 'Default', 'acidum' );

$options = array(
	'general' => array(
		'title'   => esc_html__( 'Layout', 'acidum' ),
		'type'    => 'tab',
		'options' => array(
			'general-box' => array(
				'type'    => 'box',
				'options' => array(		
					'navbar-layout'    => array(
						'label' => esc_html__( 'Navbar', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'default'  		=> esc_html__( 'Default', 'acidum' ),
							'fixed-left'  		=> esc_html__( 'Fixed Left', 'acidum' ),
							'disabled'  	=> esc_html__( 'Hidden', 'acidum' ),
						),
						'value' => 'default',
					),
					'body-color'    => array(
						'label' => esc_html__( 'Body Color', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Page Background Color', 'acidum' ),
						'choices' => array(
							'default'  => esc_html__( 'Black', 'acidum' ),
							'gray'  => esc_html__( 'Dark Blue', 'acidum' ),
						),
						'value' => 'default',
					),					
					'header-layout'    => array(
						'label' => esc_html__( 'Page Header', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'default'  => esc_html__( 'Default', 'acidum' ),
							'disabled' => esc_html__( 'Hidden', 'acidum' ),
						),
						'value' => 'default',
					),
					'margin-layout'    => array(
						'label' => esc_html__( 'Content Margin', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Margin control for content', 'acidum' ),
						'choices' => array(
							'default'  => esc_html__( 'Top And Bottom', 'acidum' ),
							'top'  => esc_html__( 'Top Only', 'acidum' ),
							'bottom'  => esc_html__( 'Bottom Only', 'acidum' ),
							'disabled' => esc_html__( 'Margin Removed', 'acidum' ),
						),
						'value' => 'default',
					),					
					'sidebar-layout'    => array(
						'label' => esc_html__( 'Sidebar', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled' => esc_html__( 'Hidden', 'acidum' ),
							'left'  => esc_html__( 'Sidebar Left', 'acidum' ),
							'right'  => esc_html__( 'Sidebar Right', 'acidum' ),
						),
						'value' => 'disabled',
					),
					'subscribe-layout'    => array(
						'label' => esc_html__( 'Subscribe Block', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Subscribe block before footer. Can be edited from Sections Menu.', 'acidum' ),
						'choices' => array(
							'default'  => esc_html__( 'Visible', 'acidum' ),
							'disabled' => esc_html__( 'Hidden', 'acidum' ),
						),
						'value' => 'Visible',
					),
					'footer-layout'    => array(
						'label' => esc_html__( 'Footer Block', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Footer block before footer. Can be edited from Sections Menu.', 'acidum' ),
						'choices' => array(
							'default'  => esc_html__( 'Visible', 'acidum' ),
							'disabled' => esc_html__( 'Hidden', 'acidum' ),
						),
						'value' => 'Visible',
					),						
					'copyright-layout'    => array(
						'label' => esc_html__( 'Copyright', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Footer block before footer. Can be edited from Sections Menu.', 'acidum' ),
						'choices' => array(
							'default'  => esc_html__( 'Default', 'acidum' ),
							'hidden' => esc_html__( 'Hidden', 'acidum' ),
						),
						'value' => 'default',
					),											
					'blog-layout'    => array(
						'label' => esc_html__( 'Blog Layout', 'acidum' ),
						'description'   => esc_html__( 'Used only for blog pages. You may ignore them on static pages.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'default'  => esc_html__( 'Default', 'acidum' ),
							'classic'  => esc_html__( 'One Column', 'acidum' ),
							'two-cols' => esc_html__( 'Two Columns', 'acidum' ),
							'three-cols' => esc_html__( 'Three Columns', 'acidum' ),
						),
						'value' => 'default',
					),
					'gallery-layout'    => array(
						'label' => esc_html__( 'Gallery Layout', 'acidum' ),
						'description'   => esc_html__( 'Used only for gallery pages. You may ignore them on static pages.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'default' => esc_html__( 'Default', 'acidum' ),
							'col-2' => esc_html__( 'Two Columns', 'acidum' ),
							'col-3' => esc_html__( 'Three Columns', 'acidum' ),
							'col-4' => esc_html__( 'Four Columns', 'acidum' ),
						),
						'value' => 'default',
					),	
					'logo-page'    => array(
						'label' => esc_html__( 'Logo for page', 'acidum' ),
						'type'  => 'upload',
					),										
				)
			),
		)
	)
);



<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$descr = '';

$options = array(
	'general' => array(
		'title'   => esc_html__( 'General', 'acidum' ),
		'type'    => 'tab',
		'options' => array(
			'general-box' => array(
				'title'   => esc_html__( 'General Settings', 'acidum' ),
				'type'    => 'box',
				'options' => array(			
					'logo_white'    => array(
						'label' => esc_html__( 'Logo', 'acidum' ),
						'desc'  => esc_html__( 'Upload logo', 'acidum' ),
						'type'  => 'upload',
					),	
					'page-loader'    => array(
						'label' => esc_html__( 'Page Loader', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled' => esc_html__( 'Disabled', 'acidum' ),
							'enabled' => esc_html__( 'Enabled', 'acidum' ),
						),
						'value' => 'enabled',
					),						
					'wc_zoom'    => array(
						'label' => esc_html__( 'WooCommerce Product Hover Zoom', 'acidum' ),
						'type'    => 'select',
						'description'   => esc_html__( 'Enables mouse hover zoom in single product page', 'acidum' ),
						'choices' => array(
							'disabled'  => esc_html__( 'Disabled', 'acidum' ),
							'enabled' => esc_html__( 'Enabled', 'acidum' ),
						),
						'value' => 'disabled',
					),
					'featured_bg'    => array(
						'label' => esc_html__( 'Featured Images as Background', 'acidum' ),
						'desc'  => esc_html__( 'Use Featured Image for Page as Header Background', 'acidum' ),
						'type'    => 'select',						
						'choices' => array(
							'disabled'  => esc_html__( 'Disabled', 'acidum' ),
							'enabled' => esc_html__( 'Enabled', 'acidum' ),
						),
						'value' => 'disabled',
					),	
					'google_api'    => array(
						'label' => esc_html__( 'Google Maps API Key', 'acidum' ),
						'desc'  => esc_html__( 'Required for contacts page, also used in widget', 'acidum' ),
						'type'  => 'text',
					),					
				),
			),
		),
	),
	'media' => array(
		'title'   => esc_html__( 'Media', 'acidum' ),
		'type'    => 'tab',
		'options' => array(

			'media-box' => array(
				'title'   => esc_html__( 'Backgrounds and patterns', 'acidum' ),
				'type'    => 'box',
				'options' => array(

					'heading_bg'    => array(
						'label' => esc_html__( 'Default Headings Icon', 'acidum' ),
						'desc'  => esc_html__( 'Will be visible under all default headers on site', 'acidum' ),
						'type'  => 'upload',
					),
					'heading_bg_white'    => array(
						'label' => esc_html__( 'Headings Icon White', 'acidum' ),
						'desc'  => esc_html__( 'For some backgrounds', 'acidum' ),
						'type'  => 'upload',
					),					
					'menu_pattern'    => array(
						'label' => esc_html__( 'Menu Pattern', 'acidum' ),
						'desc'  => esc_html__( 'Also used for go top icon', 'acidum' ),
						'type'  => 'upload',
					),					
					'header_bg'    => array(
						'label' => esc_html__( 'Inner Header Background', 'acidum' ),
						'desc'  => esc_html__( 'By default header is gray, you can replace it with background image', 'acidum' ),
						'type'  => 'upload',
					),
					'footer_bg'    => array(
						'label' => esc_html__( 'Footer Background', 'acidum' ),
						'type'  => 'upload',
					),					
					'404_bg'    => array(
						'label' => esc_html__( '404 Page Background', 'acidum' ),
						'type'  => 'upload',
					),	
				)
			)
		)
	),	
	'navbar' => array(
		'title'   => esc_html__( 'Navbar', 'acidum' ),
		'type'    => 'tab',
		'options' => array(
			'navbar-box' => array(
				'title'   => esc_html__( 'Navbar Settings', 'acidum' ),
				'type'    => 'box',
				'options' => array(
					'navbar-affix'    => array(
						'label' => esc_html__( 'Navbar sticked', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled'  => esc_html__( 'Static navbar', 'acidum' ),
							'affix'  => esc_html__( 'Sticked navbar', 'acidum' ),
						),
						'value' => 'disabled',
					),					
					'basket-icon'    => array(
						'label' => esc_html__( 'Always show Basket icon', 'acidum' ),
						'desc'   => esc_html__( 'Basket Icon will be visible in navbar with 3-bars menu.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled'  => esc_html__( 'Desktop Only', 'acidum' ),
							'visible'  => esc_html__( 'Visible Always', 'acidum' ),
						),
						'value' => 'visible',
					),
					'social-icons-mobile'    => array(
						'label' => esc_html__( 'Menu Social Icons Mobile', 'acidum' ),
						'desc'   => esc_html__( 'How to show social icons in mobile menu', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled'  => esc_html__( 'Hidden', 'acidum' ),
							'before'  => esc_html__( 'Before menu items', 'acidum' ),
							'after'  => esc_html__( 'After menu items', 'acidum' ),
						),
						'value' => 'after',
					),					
					'social-icons' => array(
		                'label' => esc_html__( 'Menu Icons', 'acidum' ),
		                'type' => 'addable-box',
		                'value' => array(),
		                'box-options' => array(
							'type'        => array(
								'type'         => 'multi-picker',
								'label'        => false,
								'desc'         => false,
								'picker'       => array(
									'type_radio' => array(
										'label'   => esc_html__( 'Type', 'acidum' ),
										'type'    => 'radio',
										'choices' => array(
											'search' => esc_html__( 'Search', 'acidum' ),
											'basket'  => esc_html__( 'WooCommerce Cart', 'acidum' ),
											'profile'  => esc_html__( 'User Profile', 'acidum' ),
											'social'  => esc_html__( 'Social Icon', 'acidum' ),
										),
									)
								),
								'choices'      => array(
									'basket'  => array(
										'count'    => array(
											'label' => esc_html__( 'Count', 'acidum' ),
											'type'    => 'select',
											'choices' => array(
												'show' => esc_html__( 'Show count label', 'acidum' ),
												'hide'  => esc_html__( 'Hide count label', 'acidum' ),
											),
											'value' => 'show',
										),											
									),
									'profile'  => array(
										'logout'    => array(
											'label' => esc_html__( 'Logout', 'acidum' ),
											'type'    => 'select',
											'choices' => array(
												'show' => esc_html__( 'Show logout popup', 'acidum' ),
												'hide'  => esc_html__( 'Hide logout popup', 'acidum' ),
											),
											'value' => 'show',
										),											
									),		
									'social'  => array(
					                    'text' => array(
					                        'label' => esc_html__( 'Label', 'acidum' ),
					                        'type' => 'text',
					                    ),
					                    'href' => array(
					                        'label' => esc_html__( 'External Link', 'acidum' ),
					                        'type' => 'text',
					                        'value' => '#',
					                    ),											
									),		
								),
								'show_borders' => false,
							),	  														                	
							'icon-type'        => array(
								'type'         => 'multi-picker',
								'label'        => false,
								'desc'         => false,
								'value'        => array(
									'icon_radio' => 'default',
								),
								'picker'       => array(
									'icon_radio' => array(
										'label'   => esc_html__( 'Icon', 'acidum' ),
										'type'    => 'radio',
										'choices' => array(
											'default'  => __( 'Default', 'acidum' ),
											'fa' => esc_html__( 'FontAwesome', 'acidum' )
										),
										'desc'    => esc_html__( 'For social icons you need to use FontAwesome in any case.',
											'acidum' ),
									)
								),
								'choices'      => array(
									'default'  => array(
									),
									'fa' => array(
										'icon_fa'  => array(
											'type'  => 'icon',
											'label' => esc_html__( 'Select Icon', 'acidum' ),
										),										
									),
								),
								'show_borders' => false,
							),
		                ),
                		'template' => '{{- type.type_radio }}',		                
                    ),			
				),
			),
		),
	),	

	'layout' => array(
		'title'   => esc_html__( 'Layout', 'acidum' ),
		'type'    => 'tab',
		'options' => array(

			'layout-box' => array(
				'title'   => esc_html__( 'Post Settings', 'acidum' ),
				'type'    => 'box',
				'options' => array(

					'blog_layout'    => array(
						'label' => esc_html__( 'Blog Layout', 'acidum' ),
						'desc'   => esc_html__( 'Default blog page layout.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'classic'  => esc_html__( 'One Column', 'acidum' ),
							'two-cols' => esc_html__( 'Two Columns', 'acidum' ),
							'three-cols' => esc_html__( 'Three Columns', 'acidum' ),
						),
						'value' => 'classic',
					),					
					'gallery_layout'    => array(
						'label' => esc_html__( 'Default Gallery Layout', 'acidum' ),
						'desc'   => esc_html__( 'Default galley page layout.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'col-2' => esc_html__( 'Two Columns', 'acidum' ),
							'col-3' => esc_html__( 'Three Columns', 'acidum' ),
							'col-4' => esc_html__( 'Four Columns', 'acidum' ),
						),
						'value' => 'col-2',
					),	
					'gallery_caption'    => array(
						'label' => esc_html__( 'Gallery Titles', 'acidum' ),
						'desc'   => esc_html__( 'Use media caption as header in images list.', 'acidum' ),
						'type'    => 'select',
						'choices' => array(
							'disabled'  => esc_html__( 'Captions disabled', 'acidum' ),
							'overlay' => esc_html__( 'Overlay Captions', 'acidum' ),
							'title' => esc_html__( 'Subheader Captions', 'acidum' ),
						),
						'value' => 'disabled',
					),						
					'excerpt_auto'    => array(
						'label' => esc_html__( 'Excerpt Blog Size', 'acidum' ),
						'desc'  => esc_html__( 'Automaticly cuts content for blogs', 'acidum' ),
						'value'	=> 350,
						'type'  => 'short-text',
					),
					'excerpt_wc_auto'    => array(
						'label' => esc_html__( 'Excerpt WooCommerce Size', 'acidum' ),
						'desc'  => esc_html__( 'Automaticly cuts description for products', 'acidum' ),
						'value'	=> 50,
						'type'  => 'short-text',
					),						
				)
			)
		)
	),
	'fonts' => array(
		'title'   => esc_html__( 'Fonts', 'acidum' ),
		'type'    => 'tab',
		'options' => array(

			'footer-box' => array(
				'title'   => esc_html__( 'Fonts Settings', 'acidum' ),
				'type'    => 'box',
				'options' => array(
					'font-text'                => array(
						'label' => __( 'Paragraph (text) Font', 'acidum' ),
						'type'  => 'typography-v2',
						'desc'	=>	esc_html__( 'Use https://fonts.google.com/ to find font you need', 'acidum' ),
						'value'      => array(
							'family'    => 'Work Sans',
							'subset'    => 'latin-ext',
							'variation' => '300',
							'size'      => 0,
							'line-height' => 0,
							'letter-spacing' => 0,
							'color'     => '#000'
						),
						'components' => array(
							'family'         => true,
							'size'           => false,
							'line-height'    => false,
							'letter-spacing' => false,
							'color'          => false
						),
					),
					'font-headers'                => array(
						'label' => __( 'Headers Font', 'acidum' ),
						'type'  => 'typography-v2',
						'value'      => array(
							'family'    => 'Teko',
							'subset'    => 'latin-ext',
							'variation' => '700',
							'size'      => 0,
							'line-height' => 0,
							'letter-spacing' => 0,
							'color'     => '#000'
						),
						'components' => array(
							'family'         => true,
							'size'           => false,
							'line-height'    => false,
							'letter-spacing' => false,
							'color'          => false
						),
					),

				),
			),
		),
	),
	'footer' => array(
		'title'   => esc_html__( 'Footer Block', 'acidum' ),
		'type'    => 'tab',
		'options' => array(

			'footer-box' => array(
				'title'   => esc_html__( 'Footer Settings', 'acidum' ),
				'type'    => 'box',
				'options' => array(

					'go_top_hide'    => array(
						'label' => esc_html__( 'Hide Go Top button in footer', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),			
					'copyrights'    => array(
						'label' => esc_html__( 'Copyrights', 'acidum' ),
						'type'  => 'wp-editor',
					),
					'footer_1_hide'    => array(
						'label' => esc_html__( 'Hide Footer 1 Widget', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),
					'footer_2_hide'    => array(
						'label' => esc_html__( 'Hide Footer 2 Widgets', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),
					'footer_3_hide'    => array(
						'label' => esc_html__( 'Hide Footer 3 Widgets', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),
					'footer_4_hide'    => array(
						'label' => esc_html__( 'Hide Footer 4 Widgets', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),						
					'footer_1_hide_mobile'    => array(
						'label' => esc_html__( 'Hide Footer 1 Widgets on mobile', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),
					'footer_2_hide_mobile'    => array(
						'label' => esc_html__( 'Hide Footer 2 Widgets on mobile', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'yes',
					),
					'footer_3_hide_mobile'    => array(
						'label' => esc_html__( 'Hide Footer 3 Widgets on mobile', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'no',
					),
					'footer_4_hide_mobile'    => array(
						'label' => esc_html__( 'Hide Footer 4 Widgets on mobile', 'acidum' ),
						'type'  => 'switch',
						'value'	=> 'yes',
					),					
				),
			),
		),
	),
);

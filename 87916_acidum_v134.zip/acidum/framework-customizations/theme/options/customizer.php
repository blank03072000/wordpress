<?php if ( ! defined( 'FW' ) ) { die( 'Forbidden' ); }

$options = array(
    'acidum_customizer' => array(
        'title' => esc_html__('ACIDUM', 'acidum'),
        'options' => array(

            'main_color' => array(
                'type' => 'color-picker',
                'value' => '#6DFDFF',
                'label' => esc_html__('Main Color', 'acidum'),
            ),
            'second_color' => array(
                'type' => 'color-picker',
                'value' => '#D10459',
                'label' => esc_html__('Secondary Color', 'acidum'),
            ),

            'gray_color' => array(
                'type' => 'color-picker',
                'value' => '#171a3b',
                'label' => esc_html__('Dark Blue', 'acidum'),
            ),
            'white_color' => array(
                'type' => 'color-picker',
                'value' => '#ffffff',
                'label' => esc_html__('White Color', 'acidum'),
            ),
            'black_color' => array(
                'type' => 'color-picker',
                'value' => '#03051a',
                'label' => esc_html__('Black Color', 'acidum'),
            ), 
            'border_radius' => array(
                'type' => 'text',
                'value' => '0px',
                'label' => esc_html__('Border Radius', 'acidum'),
            ),
            'nav_opacity' => array(
                'type'  => 'slider',
                'value' => 0,
                'properties' => array(
                    'min' => 0,
                    'max' => 1,
                    'step' => 0.05,
                ),
                'label' => esc_html__('Navbar Opacity (0 - 1)', 'acidum'),
            ), 
            'nav_opacity_scroll' => array(
                'type'  => 'slider',
                'value' => 0.95,
                'properties' => array(
                    'min' => 0,
                    'max' => 1,
                    'step' => 0.05,
                ),
                'label' => esc_html__('Navbar Sticked Opacity (0 - 1)', 'acidum'),
            ),
            'logo_height' => array(
                'type'  => 'slider',
                'value' => 65,
                'properties' => array(

                    'min' => 16,
                    'max' => 160,
                    'step' => 1,

                ),
                'label' => esc_html__('Logo Max Height, px', 'acidum'),
            ),        
        )
    )    
);

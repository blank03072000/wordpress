	<?php
/**
 * The default template for displaying content inner item
 *
 * Used for both single and index/archive/search.
 */

?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<?php
		if ( in_array( 'category', get_object_taxonomies( get_post_type() ) ) && acidum_categorized_blog() ) {

			$category = get_the_category();
			if ( !empty($category) ) echo '<h5 class="cat color-second">'. $category[0]->name .'</h5>';
		}
		?>		
        <a href="<?php esc_url( the_permalink() ); ?>" class="header"><h2><?php the_title(); ?></h2></a>
	    <a href="<?php the_permalink(); ?>" class="photo">
	        <?php echo the_post_thumbnail(); ?>    
	    </a>	    
	    <div class="description">
	        <div class="text text-page margin-bottom-0">
			<?php if ( is_search() ) : ?> 
				<?php
					the_excerpt();
				?>
			<?php else : ?>
				<?php
					add_filter( 'the_content', 'acidum_excerpt' );
					the_content( esc_html__( 'Read more &rarr;', 'acidum' ) );
				?>
			<?php endif; ?>
	        </div>
		    <div class="blog-info">
				<a href="<?php esc_url( the_permalink() ); ?>" class="date"><span class="fa fa-clock-o color-second"></span> <?php echo get_the_date(); ?></a>
				<?php
	            	if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {

		                echo '<ul>';
						if ( function_exists( 'pvc_post_views' ) ) {

							echo '<li class="icon-fav color-main">
								<span class="fa fa-eye color-second"></span> '.esc_html( strip_tags( pvc_post_views(get_the_ID(), false) ) ) .'
							</li>';
						}
	                    
	                    	echo '<li class="icon-comments color-main"><span class="fa fa-commenting color-second"></span> '. get_comments_number( '0', '1', '%' ) .'</li>';
		                echo '</ul>';
	                }
				?>	
		    </div>	   	        
	    </div> 
	</article>

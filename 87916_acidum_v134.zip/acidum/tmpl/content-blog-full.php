<?php
/**
 * Full blog post
 */

?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<div class="image"><?php echo the_post_thumbnail( 'acidum-big' ); ?></div>

	    <div class="description">
	        <div class="text text-page">
				<?php
					the_content();
					wp_link_pages( array(
						'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'acidum' ) . '</span>',
						'after'       => '</div>',
						'link_before' => '<span>',
						'link_after'  => '</span>',
					) );
				?>
	        </div>
	    </div>	    
	    <div class="blog-info">
			<a href="<?php esc_url( the_permalink() ); ?>" class="date"><span class="fa fa-clock-o color-second"></span> <?php echo get_the_date(); ?></a>
			<?php
            	if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) {

	                echo '<ul>';
					if ( function_exists( 'pvc_post_views' ) ) {

						echo '<li class="icon-fav color-main">
							<span class="fa fa-eye color-second"></span> '.esc_html( strip_tags( pvc_post_views(get_the_ID(), false) ) ) .'
						</li>';
					}
                    
                    	echo '<li class="icon-comments color-main"><span class="fa fa-commenting color-second"></span> '. get_comments_number( '0', '1', '%' ) .'</li>';
	                echo '</ul>';
                }
			?>	
	    </div>	  
	    <?php if ( ! post_password_required() && ( comments_open() || get_comments_number() ) ) : ?>


		<?php endif; ?>
		<?php the_tags( '<div class="tags-short"><strong>' . esc_html__( 'Tags:', 'acidum' ) . '</strong> ', ', ', '</div>' ); ?>
	    <?php
		if ( in_array( 'category', get_object_taxonomies( get_post_type() ) ) && acidum_categorized_blog() ) {

			echo '<div class="cats-short">';
			echo '<strong>' . esc_html__( 'Category:', 'acidum' ) . '</strong> ';
			echo get_the_category_list( esc_html_x( ', ', 'Used between list items, there is a space after the comma.', 'acidum' ) );
			echo '</div>';
		}
		?>		
	
		<?php if ( acidum_plugin_is_active( 'simple-share-buttons-adder' ) ) { echo do_shortcode( '[ssba]' );} ?>



	</article>

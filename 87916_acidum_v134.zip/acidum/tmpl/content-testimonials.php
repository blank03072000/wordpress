<?php
/**
	Testimonials Single Item
 */

$subheader = fw_get_db_post_option(get_The_ID(), 'subheader');

?>
<div class="col-lg-6">
	<article class="inner matchHeight">
		<div class="top">
			<?php the_post_thumbnail('acidum-client'); ?>
			<div class="name color-main"><?php the_title(); ?></div>
			<?php if (!empty($subheader)) echo '<div class="subheader">'. wp_kses_post($subheader) .'</div>'; ?>
		</div>
		<div class="text"><span class="fa fa-quote-right"></span><?php the_content() ?></div>	
	</article>
</div>

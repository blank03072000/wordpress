<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/**
 * Theme Configuration
 */


/*
* Adding additional TinyMCE options
*/
function acidum_wpb_mce_buttons_2($buttons) {
    array_unshift($buttons, 'styleselect');
    return $buttons;
}
add_filter('mce_buttons_2', 'acidum_wpb_mce_buttons_2');

function acidum_mce_before_init_insert_formats( $init_array ) {  

    $style_formats = array(

        array(  
            'title' => esc_html__('Main Color', 'acidum'),
            'block' => 'span',  
            'classes' => 'color-main',
            'wrapper' => true,
        ),  
        array(  
            'title' => esc_html__('Second Color', 'acidum'),
            'block' => 'span',  
            'classes' => 'color-second',
            'wrapper' => true,
        ),  
        array(  
            'title' => esc_html__('XLarge Text', 'acidum'),
            'block' => 'span',  
            'classes' => 'text-xl',
            'wrapper' => true,
             
        ),  
        array(  
            'title' => esc_html__('Large Text', 'acidum'),
            'block' => 'span',  
            'classes' => 'text-large',
            'wrapper' => true,
             
        ),  
        array(  
            'title' => esc_html__('Small Text', 'acidum'),
            'block' => 'span',  
            'classes' => 'text-sm',
            'wrapper' => true,
             
        ),        
        array(  
            'title' => esc_html__('Double Line Height', 'acidum'), 
            'block' => 'span',  
            'classes' => 'line-height-2',
            'wrapper' => true, 
        ),        
        array(  
            'title' => esc_html__('List Arrow', 'acidum'),
            'selector' => 'ul',
            'classes' => 'ul-arrow',
        ),          
        array(  
            'title' => esc_html__('List Checked', 'acidum'),
            'selector' => 'ul',
            'classes' => 'check',
        ),        
        array(  
            'title' => esc_html__('List Two Column', 'acidum'),
            'selector' => 'ul',
            'classes' => 'two-col',
        ),            
    );  
    $init_array['style_formats'] = json_encode( $style_formats );  
     
    return $init_array;  
} 
add_filter( 'tiny_mce_before_init', 'acidum_mce_before_init_insert_formats' ); 


/**
 * Config used for lt-ext plugin to set Visual Composer configuration
 */
add_filter( 'ltx_get_vc_config', 'acidum_vc_config', 10, 1 );
function acidum_vc_config( $value ) {

    return array(
    	'sections'	=>	array(
			esc_html__("Row with 5 Columns", 'acidum') 		=> "row-5-cols",
			esc_html__("Columns with Borders", 'acidum') 		=> "col-borders",
			esc_html__("Booking Form", 'acidum') 		=> "book-form",
			esc_html__("Banners Grid", 'acidum') 		=> "banners-grid",			
			esc_html__("Open Hours", 'acidum') 		=> "open-hours",			
			esc_html__("Background Hidden on mobile", 'acidum') 		=> "bg-mobile-hide",			
			esc_html__("Displaced floating section", 'acidum') 		=> "displaced-top",			
			esc_html__("DJ Slider", 'acidum') 		=> "slider-dj",
		),
		'background' => array(
			esc_html__( "Theme Main Color", 'acidum' ) => "theme_color",
			esc_html__( "Second Color", 'acidum' ) => "second",			
			esc_html__( "Gray", 'acidum' ) => "gray",
			esc_html__( "Black", 'acidum' ) => "black",			
			esc_html__( "White", 'acidum' ) => "white",
		),
		'overlay'	=> array(
/*			esc_html__( "Black Overlay", 'acidum' ) => "black",			*/
			esc_html__( "Dark Overlay", 'acidum' ) => "dark",
			esc_html__( "Main Color Overlay", 'acidum' ) => "main",
			esc_html__( "Second Color Overlay", 'acidum' ) => "second",
/*			esc_html__( "Black Triangle Overlay", 'acidum' ) => "black-corner",			*/
		),

	);
}

/**
 * Additional styles init
 */
function acidum_css_style() {

	global $wp_query;

	wp_enqueue_style( 'acidum_bootstrap_css', get_template_directory_uri() . '/assets/css/bootstrap-grid.css', array(), '1.0' );

	wp_enqueue_style( 'acidum_plugins_css', get_template_directory_uri() . '/assets/css/plugins.css', array(), '1.0' );

	wp_enqueue_style( 'acidum_theme_style', get_stylesheet_uri(), array( 'acidum_bootstrap_css', 'acidum_plugins_css' ), '1.3' );

	if ( function_exists( 'fw_get_db_settings_option' ) ){

		$heading_bg = fw_get_db_settings_option( 'heading_bg' );
		if (! empty( $heading_bg ) ) {

			wp_add_inline_style( 'acidum_theme_style', '.heading.head-subheader.align-center { background-image: url(' . esc_attr( $heading_bg['url'] ) . ') !important; } ' );
		}

		$heading_bg_white = fw_get_db_settings_option( 'heading_bg_white' );
		if (! empty( $heading_bg_white ) ) {

			wp_add_inline_style( 'acidum_theme_style', '.bg-color-second .heading.head-subheader.align-center { background-image: url(' . esc_attr( $heading_bg_white['url'] ) . ') !important; } ' );
		}

		$header_bg = fw_get_db_settings_option( 'header_bg' );
		$featured_bg = fw_get_db_settings_option( 'featured_bg' );
		if (! empty( $header_bg ) ) {

			if ( !is_single() && has_post_thumbnail() && $featured_bg == 'enabled') {

				wp_add_inline_style( 'acidum_theme_style', '.page-header { background-image: url(' . esc_url( get_the_post_thumbnail_url( $wp_query->get_queried_object_id(), 'full') ) . ') !important; } ' );
			}
				else {

				wp_add_inline_style( 'acidum_theme_style', '.page-header { background-image: url(' . esc_url( $header_bg['url'] ) . ') !important; } ' );
			}
		}


		$menu_pattern = fw_get_db_settings_option( 'menu_pattern' );
		if (! empty( $menu_pattern ) ) {

			wp_add_inline_style( 'acidum_theme_style', '.go-top span, nav.navbar #navbar ul.navbar-nav > li > a span:after { background-image: url(' . esc_attr( $menu_pattern['url'] ) . ') !important; } ' );
		}

		$bg_404 = fw_get_db_settings_option( '404_bg' );
		if (! empty( $bg_404 ) ) {

			wp_add_inline_style( 'acidum_theme_style', 'body.error404 { background-image: url(' . esc_attr( $bg_404['url'] ) . ') !important; } ' );
		}

		$go_top_img = fw_get_db_settings_option( 'go_top_img' );
		if (! empty( $go_top_img ) ) {

			wp_add_inline_style( 'acidum_theme_style', '.go-top:before { background-image: url(' . esc_attr( $go_top_img['url'] ) . ') !important; } ' );
		}

		$logo_height = fw_get_db_customizer_option('logo_height');
		if ( !empty($logo_height) ) {

			wp_add_inline_style( 'acidum_theme_style', 'nav.navbar .logo img { max-height: '.esc_attr($logo_height).'px; } ' );			
		}
	}
}
add_action( 'wp_enqueue_scripts', 'acidum_css_style' );



/**
 * Register widget areas.
 *
 */
function acidum_action_theme_widgets_init() {

	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar Default', 'acidum' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Appears in the right/left section of the site.', 'acidum' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="header-widget">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar WooCommerce', 'acidum' ),
		'id'            => 'sidebar-wc',
		'description'   => esc_html__( 'Appears in the right/left section of the site.', 'acidum' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="header-widget">',
		'after_title'   => '</h3>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer 1', 'acidum' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'Appears in the footer section of the site.', 'acidum' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="header-widget">',
		'after_title'   => '</h4>',
	) );			

	register_sidebar( array(
		'name'          => esc_html__( 'Footer 2', 'acidum' ),
		'id'            => 'footer-2',
		'description'   => esc_html__( 'Appears in the footer section of the site.', 'acidum' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="header-widget">',
		'after_title'   => '</h4>',
	) );			

	register_sidebar( array(
		'name'          => esc_html__( 'Footer 3', 'acidum' ),
		'id'            => 'footer-3',
		'description'   => esc_html__( 'Appears in the footer section of the site.', 'acidum' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="header-widget">',
		'after_title'   => '</h4>',
	) );			

	register_sidebar( array(
		'name'          => esc_html__( 'Footer 4', 'acidum' ),
		'id'            => 'footer-4',
		'description'   => esc_html__( 'Appears in the footer section of the site.', 'acidum' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="header-widget">',
		'after_title'   => '</h4>',
	) );			

}

add_action( 'widgets_init', 'acidum_action_theme_widgets_init' );


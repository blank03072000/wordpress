<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }


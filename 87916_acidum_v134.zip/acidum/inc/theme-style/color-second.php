<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

// Color
$theme_style .= "
.tribe-events-list-separator-month,
.tribe-events-pg-template dl .tribe-organizer,
.tribe-events-pg-template .tribe-events-cost,
.footer-widget-area .header-widget,
.tariff-item .price,
ul.ul-arrow li::before, ul.arrow li::before, ul.disc li::before, ul.check li::before,
.paging-navigation .pagination .page-numbers:hover, .page-numbers .pagination .page-numbers:hover,
.select-wrap::after,
header.page-header h1,
.ltx-media-element .meta h5,
.wpcf7-form-control-wrap::after,
.woocommerce ul.products li.product a:hover,
.blog-info li .fa,
.woocommerce-MyAccount-navigation aside ul li::before, .widget-area aside ul li::before,
.woocommerce ul.products li.product .woocommerce-loop-category__title:hover,
.woocommerce ul.products li.product .woocommerce-loop-product__title:hover,
.woocommerce ul.products li.product h3:hover,
a:focus,a:hover,
aside a,
.woocommerce nav.woocommerce-pagination ul .prev:hover:after,
.woocommerce nav.woocommerce-pagination ul .next:hover:after,
.woocommerce nav.woocommerce-pagination ul .prev.disabled,
.woocommerce nav.woocommerce-pagination ul .next.disabled,
.woocommerce nav.woocommerce-pagination ul .prev:before,
.woocommerce nav.woocommerce-pagination ul .next:after,
aside ul li a:hover,
.header-widget,
.team-item p,
.tabs-cats.menu-filter li span,
.blog article .description .header:hover,
footer a,
.blog-sc article .blog-info .cat,
.countUp-item h4 span,
.woocommerce form .form-row .required,
.woocommerce ul.products li.product .price ins,
.alert.alert-error .fa, .alert.alert-error .header, .alert.alert-error p,
.btn.btn-add-bordered,
.testimonials-list.layout-col1-shadow .arrow-left, .testimonials-list.layout-col1-shadow .arrow-right,
.testimonials-list.layout-col1-shadow .inner .name,
.testimonials-list .inner .name,
.tariff-slider-sc .ul-yes,
.color-second,
.top-bar .cart:hover, .top-bar .cart .fa:hover,
.products-sc.products-sc-fastfood article:hover .header h5,
.heading.color-second .header,
.heading.color-second h1, .heading.color-second h2, .heading.color-second h3, 
.heading.color-second h4, .heading.color-second h5, .heading.color-second h6,
.blog-sc.layout-date-top article .header > *:hover,
.products-sc.products-sc-fastfood .price.color-second,
.heading.subcolor-second .subheader,
nav.navbar #navbar ul.navbar-nav ul.children li.current_page_item > a,  
nav.navbar #navbar ul.navbar-nav ul.sub-menu li.current_page_item > a,
#block-footer .social-icons-list .fa,
.blog .more,
.block-icon.layout-cols6 li h5,
.block-icon.icon-h-right span,
.block-icon.layout-inline.i-transparent a,
.block-icon.layout-inline.i-transparent span,
.blog-post .tags-short strong,
.blog-post .cats-short strong,
.social-small li a
{ color: {$css['second_color']}; }

.tribe-events-list-event-title a,
nav.navbar #navbar .mega-menu .mega-menu-col > a,
nav.navbar #navbar .mega-menu .mega-menu-col:hover > a,
.wpb-js-composer .vc_tta-color-grey.vc_tta-style-flat .vc_tta-tab > a
{ color: {$css['second_color']} !important; }


@media (min-width: 1199px) {

	nav.navbar #navbar ul.navbar-nav ul.children li.current-menu-item > a,
	nav.navbar #navbar ul.navbar-nav ul.sub-menu li.current-menu-item > a,
	nav.navbar #navbar ul.navbar-nav ul.children li.current-menu-parent > a,
	nav.navbar #navbar ul.navbar-nav ul.sub-menu li.current-menu-parent > a,
	nav.navbar #navbar ul.navbar-nav ul.children li.current_page_parent > a,
	nav.navbar #navbar ul.navbar-nav ul.sub-menu li.current_page_parent > a,
	nav.navbar #navbar ul.navbar-nav ul.children li.current_page_item > a,
	nav.navbar #navbar ul.navbar-nav ul.sub-menu li.current_page_item > a
	{ color: {$css['second_color']};  }
}

";

// Background
$theme_style .= "
#tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option a:hover,
#tribe-events .tribe-events-button,
.tribe-events-calendar thead th,
.social-big.dj-social li a,
.ltx-media-element .mejs-container .mejs-controls .mejs-horizontal-volume-slider .mejs-horizontal-volume-current, .ltx-media-element .mejs-container .mejs-controls .mejs-time-rail .mejs-time-loaded,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-second,
.woocommerce a.button.btn-second,
.woocommerce div.product .woocommerce-tabs ul.tabs li,
.woocommerce-MyAccount-navigation .header-widget, .widget-area .header-widget,
.paging-navigation .pagination .page-numbers:not(.next):not(.prev).current,
.ltx-contact-form-7.form-style-secondary form input[type=\"submit\"],
.ltx-media-element .mejs-container .mejs-controls .mejs-button button,
.woocommerce a.button,
.events-posts-sc .date,
.image-video span,
.progressBar .bar div,
.woocommerce div.quantity span,
.woocommerce div.product form.cart div.quantity span,
.woocommerce-page div.product form.cart div.quantity span,
.testimonials-list .arrow-left, .testimonials-list .arrow-right,
.woocommerce-product-search input[type=\"submit\"]:hover,
.wp-searchform input[type=\"submit\"]:hover,
form.post-password-form input[type=\"submit\"]:hover,
form.search-form input[type=\"submit\"]:hover,
form.wpcf7-form input[type=\"submit\"]:hover,
form.form input[type=\"submit\"]:hover,
form.comment-form input[type=\"submit\"]:hover,
form input[type=\"submit\"]:hover,
.comment-text table thead th,
.text-page table thead th,
.pace .line,
nav.navbar #navbar ul.navbar-nav ul.children > li:hover > a,
nav.navbar #navbar ul.navbar-nav ul.sub-menu > li:hover > a,
.alert.alert-warning,
nav.navbar .cart .count,
nav.navbar .nav-right .cart .count,
.bg-color-second.vc_row-fluid,
.bg-color-second.vc_section,
.bg-color-second.vc_column_container .vc_column-inner,
.top-bar .cart .count, .navbar .cart .count,
.woocommerce span.onsale,
.bg-color-second.vc_section,
.bg-color-second.vc_column_container .vc_column-inner,
.btn.color-hover-second:hover,
.cart .count,
.btn.btn-second,
.btn.btn-add,
.block-icon.icon-ht-left a,
.block-icon.icon-ht-left span,
.block-icon.icon-ht-right span,
.block-icon.icon-top a,
.block-icon.icon-top span,
.block-icon li .bg-main,
.bg-color-second.vc_section,
.bg-color-second.vc_column_container .vc_column-inner,
.like-contact-form-7.form-style-secondary form input[type=\"submit\"],
.image-video::after,
.bg-overlay-second:after
{ background-color: {$css['second_color']}; }

nav.navbar #navbar .mega-menu .mega-menu-col:hover ul li a:hover,
.woocommerce table.shop_table td.actions .button,
.vc_progress_bar .vc_single_bar .vc_bar,
.wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic .vc_tta-tab:not(.vc_active) > a
{ background-color: {$css['second_color']} !important; }


@media (max-width: 1199px) {
	nav.navbar #navbar
	{ background-color: {$css['second_color']}; }
}

@keyframes glow {
  0%,
  100% {
    -webkit-box-shadow: 0 0 30px {$css['second_color']};
    -moz-box-shadow: 0 0 30px {$css['second_color']};
    box-shadow: 0 0 30px {$css['second_color']};
  }
  50% {
    -webkit-box-shadow: 0 0 0px {$css['second_color']};
    -moz-box-shadow: 0 0 0px {$css['second_color']};
    box-shadow: 0 0 0px {$css['second_color']};
  }
}

";

// Border-color
$theme_style .= "
.tribe-events-calendar thead th,
.woocommerce div.quantity input[type=\"number\"], .woocommerce div.product form.cart div.quantity input[type=\"number\"],
.btn.btn-add,
.btn.btn-add-bordered,
.events-slider .swiper-pagination-bullet
{ border-color: {$css['second_color']}; }
";


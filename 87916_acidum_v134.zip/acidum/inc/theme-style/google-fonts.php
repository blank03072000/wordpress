<?php

/**
 * Including google fonts
 */
$acidum_font_main = fw_get_db_settings_option( 'font-text' );
$acidum_font_headers = fw_get_db_settings_option( 'font-headers' );

$acidum_google_fonts = array();
$acidum_google_fonts[$acidum_font_main['family']][$acidum_font_main['variation']] = true;
$acidum_google_fonts[$acidum_font_headers['family']][$acidum_font_headers['variation']] = true;
$acidum_google_subsets[$acidum_font_main['subset']] = true;
$acidum_google_subsets[$acidum_font_headers['subset']] = true;

$theme_style .= "html,body,div,table { 
	font-family: '".esc_attr($acidum_font_main['family'])."';
	font-weight: ".esc_attr($acidum_font_main['variation']).";
}";

$theme_style .= "h1, h2, h3, h4, h5, h6, .header, .subheader, nav.navbar a, .btn, .button, button, input[type=\"submit\"], .breadcrumbs { 
	font-family: '".esc_attr($acidum_font_headers['family'])."';
	font-weight: ".esc_attr($acidum_font_headers['variation']).";
}";


$family = $subset = '';
foreach ( $acidum_google_fonts as $font => $styles ) {

	if ( !empty($family) ) $family .= "%7C";
    $family .= str_replace( ' ', '+', $font ) . ':' . implode( ',', array_keys($styles) ).',700';
}

foreach ( $acidum_google_subsets as $subset_ => $val ) {

	if ( !empty($subset) ) $subset .= ",";
    $subset .= $subset_;
}

$query_args = array( 'family' => $family, 'subset' => $subset );
wp_enqueue_style( 'acidum_google_fonts', esc_url( add_query_arg( $query_args, '//fonts.googleapis.com/css' ) ), array(), null );


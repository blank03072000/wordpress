<?php if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

// Color
$theme_style .= "
#tribe-events-content a:hover,
.tribe-events-event-cost span,
#top-search input[type=\"text\"],
nav.navbar #navbar ul.navbar-nav .ltx-fa-icon a,
#block-footer,
a,
.events-posts-sc .item-simple:hover h5,
.wpcf7-radio,
.wpcf7-checkbox,
.tabs-cats li span.cat-active,
nav.navbar .nav-right .top-search input[type=\"text\"],
.woocommerce table.shop_table .woocommerce-cart-form__cart-item .product-name a,
.woocommerce div.product p.price del, .woocommerce div.product span.price del, .woocommerce ul.products li.product .price del,
.woocommerce div.product p.price del,
form input[type=\"text\"],
.woocommerce-MyAccount-navigation aside ul li a, .widget-area aside ul li a,
.blog-block .blog-info .date,
.paging-navigation .pagination .page-numbers,
.woocommerce-MyAccount-navigation aside a, .widget-area aside a,
footer .go-top.go-top-text,
.gallery-sc .item .photo .hover,
.hover-slide:hover .header,
.comments-area .comments-title,
.comments-area .comment-reply-link,
a.black:hover,
a.black:focus,
.team-item h4,
nav.navbar .nav-right .top-search a,
.woocommerce nav.woocommerce-pagination ul .page-numbers:not(.next):not(.prev),
.widget_calendar caption,
nav.navbar .nav-right .cart,
nav.navbar.navbar-transparent .nav-right .cart,
header.page-header .breadcrumbs li,
header.page-header .breadcrumbs li a:hover,
.testimonials-list p,
.blog-sc article .blog-info .cat-div,
.blog-sc article .blog-info .date,
#block-footer .widget_nav_menu ul li a:before,
.tariff-item .header,
.products-sc article:hover .header,
.color-main,
header.page-header,
div.top-bar.container .cart:hover,div.top-bar.container .cart:focus,
.top-search a:focus,
.top-search a:hover,
.comments-area .comment-info .comment-author,
.comments-area .comment-reply-link:hover,
.comments-area .comment-reply-link:before,
.heading.spanned h4,
.heading.color-main .header,
.heading.subcolor-main .subheader,
.multi-doc .block-right .descr,
#block-footer .social-icons-list a:hover,
#block-footer .address li span,
#block-footer .address li a:hover,
#block-footer .widget_nav_menu ul li.active a,
body.body-black-dark .blog article .description .header,
.blog-post .tags-short,
.blog-post .cats-short,
.events-list .date .date-day,
.gallery-page .descr .fa,
.woocommerce #payment #place_order.btn-second:hover,
.woocommerce-page #payment #place_order.btn-second:hover,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-second:hover,
.woocommerce div.product form.cart .button.btn-second:hover,
.woocommerce #respond input#submit.btn-second:hover,
.woocommerce a.button.btn-second:hover,
.woocommerce button.button.btn-second:hover,
.woocommerce input.button.btn-second:hover,
.button.btn-second:hover,input[type=\"submit\"].btn-second:hover,
.wpcf7-submit.btn-second:hover,
.btn.btn-second:hover,
.woocommerce-product-search input[type=\"submit\"].btn-second:hover,
.wp-searchform input[type=\"submit\"].btn-second:hover,form.post-password-form input[type=\"submit\"].btn-second:hover,form.search-form input[type=\"submit\"].btn-second:hover,form.wpcf7-form input[type=\"submit\"].btn-second:hover,form.form input[type=\"submit\"].btn-second:hover,form.comment-form input[type=\"submit\"].btn-second:hover,form input[type=\"submit\"].btn-second:hover,
.woocommerce #payment #place_order.btn-default-bordered,
.woocommerce-page #payment #place_order.btn-default-bordered,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-default-bordered,
.woocommerce div.product form.cart .button.btn-default-bordered,
.woocommerce #respond input#submit.btn-default-bordered,
.woocommerce a.button.btn-default-bordered,
.woocommerce button.button.btn-default-bordered,
.woocommerce input.button.btn-default-bordered,
.button.btn-default-bordered,input[type=\"submit\"].btn-default-bordered,
.wpcf7-submit.btn-default-bordered,
.btn.btn-default-bordered,
.woocommerce-product-search input[type=\"submit\"].btn-default-bordered,
.wp-searchform input[type=\"submit\"].btn-default-bordered,form.post-password-form input[type=\"submit\"].btn-default-bordered,form.search-form input[type=\"submit\"].btn-default-bordered,form.wpcf7-form input[type=\"submit\"].btn-default-bordered,form.form input[type=\"submit\"].btn-default-bordered,form.comment-form input[type=\"submit\"].btn-default-bordered,form input[type=\"submit\"].btn-default-bordered,
.ltx-contact-form-7 form input[type=\"text\"], .ltx-contact-form-7 form input[type=\"email\"], .ltx-contact-form-7 form input[type=\"number\"], .ltx-contact-form-7 form input[type=\"date\"], .ltx-contact-form-7 form input[type=\"time\"], .ltx-contact-form-7 form textarea, 
.ltx-contact-form-7 form .select-wrap,
.select-wrap select,
.alert.alert-success .fa,
.alert.alert-success p,
.alert.alert-success .header,
.alert.alert-warning p,
.alert.alert-warning .fa,
.alert.alert-warning .header,
.block-descr h4,
.wpb-js-composer .vc_tta-panel .vc_tta-icon,
.tags a,
.tags a:hover,
.products-sc article .price.color-main,
.zs-enabled .zs-arrows .arrow-right:hover,
.zs-enabled .zs-arrows .arrow-left:hover,
.zs-enabled .zs-arrows .arrow-right:hover:before,
.zs-enabled .zs-arrows .arrow-left:hover:before,
.zs-enabled .zs-arrows .arrow-right:hover:after,
.zs-enabled .zs-arrows .arrow-left:hover:after,
.woocommerce .product_meta > span span,
.woocommerce div.product .woocommerce-product-rating,
.woocommerce .star-rating span,
.woocommerce-MyAccount-navigation ul li:before,
.woocommerce-MyAccount-navigation ul li a:hover,
.woocommerce-message::before,
nav.navbar #navbar ul.navbar-nav .current_page_parent > a,  nav.navbar #navbar ul.navbar-nav .current_page_item > a,
nav.navbar #navbar ul.navbar-nav > li.hasSub:hover > a,
nav.navbar #navbar ul.navbar-nav a:hover,
nav.navbar #navbar ul.navbar-nav ul,
nav.navbar #navbar ul.navbar-nav > li.page_item_has_children:hover > ul, 
ul.navbar-nav > li.current-menu-ancestor > a,
nav.navbar #navbar ul.navbar-nav > li.current-menu-item > a,
nav.navbar #navbar ul.navbar-nav > li.current-menu-parent > a,
nav.navbar #navbar ul.navbar-nav > li.current_page_parent > a,
nav.navbar #navbar ul.navbar-nav > li.current_page_item > a,
nav.navbar.navbar-transparent .nav-right .cart:hover,
.navbar.navbar-transparent .top-search a:hover,
nav.navbar .nav-right .cart:hover,
nav.navbar .nav-right .cart:focus,
.social-icons-list li span.fa,
.woocommerce.widget_shopping_cart .quantity .amount,
.woocommerce .widget_shopping_cart .quantity .amount,
.woocommerce div.product p.price,
.woocommerce div.product span.price,
.woocommerce ul.products li.product .price,
.woocommerce table.shop_table .woocommerce-cart-form__cart-item .product-subtotal,
.woocommerce table.shop_table .woocommerce-cart-form__cart-item .product-price,
form textarea, .form-row textarea, form input[type=\"password\"], .form-row input[type=\"password\"], form input[type=\"search\"], .form-row input[type=\"search\"], form input[type=\"number\"], .form-row input[type=\"number\"], form input[type=\"time\"], .form-row input[type=\"time\"], form input[type=\"date\"], .form-row input[type=\"date\"], form input[type=\"email\"], .form-row input[type=\"email\"], form input[type=\"tel\"], .form-row input[type=\"tel\"], form input[type=\"text\"], .form-row input[type=\"text\"]
{ color: {$css['main_color']};  }


@media (min-width: 1199px) {

	nav.navbar #navbar ul.navbar-nav > li.current-menu-ancestor > a, 
	nav.navbar #navbar ul.navbar-nav > li.current-menu-item > a, 
	nav.navbar #navbar ul.navbar-nav > li.current-menu-parent > a, 
	nav.navbar #navbar ul.navbar-nav > li.current_page_parent > a, 
	nav.navbar #navbar ul.navbar-nav > li.current_page_item > a,
	nav.navbar #navbar ul.navbar-nav a:hover
	{ color: {$css['main_color']};  }
}

@media (min-width: 991px) {

	nav.navbar.navbar-transparent #navbar ul.navbar-nav > li > a:hover
	{ color: {$css['main_color']};  }
}

.blog article .header:hover h2,
.blog a.header:hover,
.wpb-js-composer .vc_tta-color-grey.vc_tta-style-classic .vc_tta-panel.vc_active .vc_tta-panel-title > a span,
.wpb-js-composer .vc_tta-accordion h4 a,
.wpb-js-composer .vc_tta-accordion h4 a span,
.wpb-js-composer .vc_tta-color-grey.vc_tta-style-flat .vc_tta-tab.vc_active > a,
#block-footer .social-small a,
#block-footer .widget_nav_menu ul li.current_page_parent a,
#block-footer .widget_nav_menu ul li.current_page_item a,
#block-footer .widget_nav_menu ul li.current_menu_item a,
#block-footer a:not(.btn):not(.fa):hover,
.vc_tta-accordion h4 a,
.vc_message_box.vc_color-info,
.alert.vc_color-info,
.vc_message_box.vc_color-info .fa,
.alert.vc_color-info .fa,
.select2-container--default .select2-selection--single .select2-selection__rendered
{ color: {$css['main_color']} !important; }
";



// Background
$theme_style .= "
.social-big.dj-social li a:hover,
form.wpcf7-form input[type=\"submit\"].btn-second,
.widget_calendar #today::before,
.social-big li a,
.hover-slide-item span,
nav.navbar #navbar .mega-menu .mega-menu-row,
.swiper-pagination .swiper-pagination-bullet-active:after,
.zs-enabled .zs-arrows .arrow-right:hover:before,
.zs-enabled .zs-arrows .arrow-left:hover:before,
.zs-enabled .zs-arrows .arrow-right:hover:after,
.zs-enabled .zs-arrows .arrow-left:hover:after,
.header-rounded > *,
.woocommerce #payment #place_order,
.woocommerce-page #payment #place_order,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button,
.woocommerce div.product form.cart .button,
.woocommerce #respond input#submit,
.woocommerce button.button,
.woocommerce input.button,
.button,input[type=\"submit\"],
.wpcf7-submit,
.btn,
.ltx-contact-form-7.form-bg-default,
.ltx-contact-form-7.form-bg-default form,
.woocommerce #payment #place_order.btn-main-filled,
.woocommerce-page #payment #place_order.btn-main-filled,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-main-filled,
.woocommerce div.product form.cart .button.btn-main-filled,
.woocommerce #respond input#submit.btn-main-filled,
.woocommerce a.button.btn-main-filled,
.woocommerce button.button.btn-main-filled,
.woocommerce input.button.btn-main-filled,
.button.btn-main-filled,input[type=\"submit\"].btn-main-filled,
.wpcf7-submit.btn-main-filled,
.btn.btn-main-filled,
.woocommerce-product-search input[type=\"submit\"].btn-main-filled,
.wp-searchform input[type=\"submit\"].btn-main-filled,
form.post-password-form input[type=\"submit\"].btn-main-filled,
form.search-form input[type=\"submit\"].btn-main-filled,
form.wpcf7-form input[type=\"submit\"].btn-main-filled,
form.form input[type=\"submit\"].btn-main-filled,
form.comment-form input[type=\"submit\"].btn-main-filled,
form input[type=\"submit\"].btn-main-filled,
.woocommerce #payment #place_order.btn-gray-filled:hover,
.woocommerce-page #payment #place_order.btn-gray-filled:hover,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-gray-filled:hover,
.woocommerce div.product form.cart .button.btn-gray-filled:hover,
.woocommerce #respond input#submit.btn-gray-filled:hover,
.woocommerce a.button.btn-gray-filled:hover,
.woocommerce button.button.btn-gray-filled:hover,
.woocommerce input.button.btn-gray-filled:hover,
.button.btn-gray-filled:hover,input[type=\"submit\"].btn-gray-filled:hover,
.wpcf7-submit.btn-gray-filled:hover,
.btn.btn-gray-filled:hover,
.woocommerce-product-search input[type=\"submit\"].btn-gray-filled:hover,
.wp-searchform input[type=\"submit\"].btn-gray-filled:hover,
form.post-password-form input[type=\"submit\"].btn-gray-filled:hover,
form.search-form input[type=\"submit\"].btn-gray-filled:hover,
form.wpcf7-form input[type=\"submit\"].btn-gray-filled:hover,
form.form input[type=\"submit\"].btn-gray-filled:hover,
form.comment-form input[type=\"submit\"].btn-gray-filled:hover,
form input[type=\"submit\"].btn-gray-filled:hover,
.woocommerce #payment #place_order.color-hover-main:hover,
.woocommerce-page #payment #place_order.color-hover-main:hover,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.color-hover-main:hover,
.woocommerce div.product form.cart .button.color-hover-main:hover,
.woocommerce #respond input#submit.color-hover-main:hover,
.woocommerce a.button.color-hover-main:hover,
.woocommerce button.button.color-hover-main:hover,
.woocommerce input.button.color-hover-main:hover,
.button.color-hover-main:hover,input[type=\"submit\"].color-hover-main:hover,
.wpcf7-submit.color-hover-main:hover,
.btn.color-hover-main:hover,
.woocommerce-product-search input[type=\"submit\"].color-hover-main:hover,
.wp-searchform input[type=\"submit\"].color-hover-main:hover,
form.post-password-form input[type=\"submit\"].color-hover-main:hover,
form.search-form input[type=\"submit\"].color-hover-main:hover,
form.wpcf7-form input[type=\"submit\"].color-hover-main:hover,
form.form input[type=\"submit\"].color-hover-main:hover,
form.comment-form input[type=\"submit\"].color-hover-main:hover,
form input[type=\"submit\"].color-hover-main:hover,
.swiper-pagination .swiper-pagination-bullet-active,
.alert.alert-important,
.social-icons-list.icon-style-round span.fa,
.zs-enabled .zs-slideshow .zs-bullets .zs-bullet,
.menu-sc .header,
.menu-sc .price,
.bg-color-theme_color.vc_row-fluid,
.bg-color-theme_color.vc_section,
.bg-color-theme_color.vc_column_container .vc_column-inner,
.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.bg-color-theme_color.vc_row-fluid,
.bg-color-theme_color.vc_section,
.bg-color-theme_color.vc_column_container .vc_column-inner,
.bg-overlay-main:after
{ background-color: {$css['main_color']}; }

.woocommerce #payment #place_order:hover, .woocommerce-page #payment #place_order:hover, .woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover, .woocommerce div.product form.cart .button:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .button:hover, input[type=\"submit\"]:hover, .btn:hover, .woocommerce-product-search input[type=\"submit\"]:hover, .wp-searchform input[type=\"submit\"]:hover, form.post-password-form input[type=\"submit\"]:hover, form.search-form input[type=\"submit\"]:hover, form.wpcf7-form input[type=\"submit\"]:hover, form.form input[type=\"submit\"]:hover, form.comment-form input[type=\"submit\"]:hover, form input[type=\"submit\"]:hover,
.ltx-contact-form-7.form-style-secondary form input[type=\"submit\"]:hover,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-second:hover,
.woocommerce table.shop_table td.actions .coupon .button,
.woocommerce #payment #place_order:hover,
.woocommerce button.button:hover,
.woocommerce a.button:hover,
.woocommerce a.button.btn-main-filled,
.woocommerce div.product form.cart .button:hover,
.btn:hover,
.bg-color-black .btn-white-filled:hover,
.woocommerce .swiper-container .arrow-left:hover,
.woocommerce .swiper-container .arrow-right:hover,
.btn.btn-active,
.vc_message_box.vc_color-warning,
alert.vc_color-warning,
.swiper-pagination-bullet-active
{ background-color: {$css['main_color']} !important; }


.img-shadow-plain img {
    -webkit-box-shadow: 30px 30px 0px 0px rgba({$css_rgb['main_color'][0]}, {$css_rgb['main_color'][1]}, {$css_rgb['main_color'][2]}, 1);
    -moz-box-shadow: 30px 30px 0px 0px rgba({$css_rgb['main_color'][0]}, {$css_rgb['main_color'][1]}, {$css_rgb['main_color'][2]}, 1);
    box-shadow: 30px 30px 0px 0px rgba({$css_rgb['main_color'][0]}, {$css_rgb['main_color'][1]}, {$css_rgb['main_color'][2]}, 1);
	
}


@media (min-width: 1200px) {
  nav.navbar #navbar ul.navbar-nav ul.children li,
  nav.navbar #navbar ul.navbar-nav ul.sub-menu li
  { background-color: {$css['main_color']}; }  
}

@media (max-width: 1199px) {
    nav.navbar #navbar .navbar-toggle .icon-bar,
    nav.navbar ul.navbar-nav ul li
  { background-color: {$css['main_color']}; }
}


.btn-hover-wrap {

  box-shadow: 0 0 0 2em rgba({$css_rgb['main_color'][0]}, {$css_rgb['main_color'][1]}, {$css_rgb['main_color'][2]}, 0);
}
@keyframes btnpulse {

  0% { box-shadow: 0 0 0 0 rgba({$css_rgb['main_color'][0]}, {$css_rgb['main_color'][1]}, {$css_rgb['main_color'][2]}, 1); }
}

.hover-slide:hover .header {
  text-shadow: 0 0 25px {$css['main_color']};
}

";


// Border-color
$theme_style .= "
.woocommerce-message,
form input[type=\"text\"],
.team-item.item-type-circle img,
.ltx-contact-form-7 form input[type=\"text\"], .ltx-contact-form-7 form input[type=\"email\"], .ltx-contact-form-7 form input[type=\"number\"], .ltx-contact-form-7 form input[type=\"date\"], .ltx-contact-form-7 form input[type=\"time\"], .ltx-contact-form-7 form textarea, .ltx-contact-form-7 form .select-wrap,
.vc_tta-tabs.vc_tta-style-flat .vc_tta-tabs-list .vc_active a span,
.countUp-item,
.tabs-cats li span.cat-active,
.swiper-pagination .swiper-pagination-bullet-active::after,
.sticky,
.footer-widget-area .null-instagram-feed .instagram-pics a img:hover,
.woocommerce #payment #place_order.btn-default-bordered,
.woocommerce-page #payment #place_order.btn-default-bordered,
.woocommerce-cart .wc-proceed-to-checkout a.checkout-button.btn-default-bordered,
.woocommerce div.product form.cart .button.btn-default-bordered,
.woocommerce #respond input#submit.btn-default-bordered,
.woocommerce a.button.btn-default-bordered,
.woocommerce button.button.btn-default-bordered,
.woocommerce input.button.btn-default-bordered,
.button.btn-default-bordered,
.nput[type=\"submit\"].btn-default-bordered,
.wpcf7-submit.btn-default-bordered,
.btn.btn-default-bordered,
.woocommerce-product-search input[type=\"submit\"].btn-default-bordered,
.wp-searchform input[type=\"submit\"].btn-default-bordered,
form.post-password-form input[type=\"submit\"].btn-default-bordered,
form.search-form input[type=\"submit\"].btn-default-bordered,
form.wpcf7-form input[type=\"submit\"].btn-default-bordered,
form.form input[type=\"submit\"].btn-default-bordered,
form.comment-form input[type=\"submit\"].btn-default-bordered,
form input[type=\"submit\"].btn-default-bordered,
.tags a,
.tags a:hover
.tariff-item.vip,
.testimonials-list .inner,
form textarea, .form-row textarea, form input[type=\"password\"], .form-row input[type=\"password\"], form input[type=\"search\"], .form-row input[type=\"search\"], form input[type=\"number\"], .form-row input[type=\"number\"], form input[type=\"time\"], .form-row input[type=\"time\"], form input[type=\"date\"], .form-row input[type=\"date\"], form input[type=\"email\"], .form-row input[type=\"email\"], form input[type=\"tel\"], .form-row input[type=\"tel\"], form input[type=\"text\"], .form-row input[type=\"text\"],
.events-slider .swiper-pagination-bullet.swiper-pagination-bullet-active
{ border-color: {$css['main_color']}; }


.woocommerce table.cart td.actions .input-text,
.select2-container .select2-selection--single
{ border-color: {$css['main_color']} !important; }

.team-item.item-type-circle:hover img {

  box-shadow: inset 0 0 0 7px {$css['main_color']}; 
}

.pace > div {

	background: {$css['main_color']};	
}

@keyframes bg-glow {
  0%,
  100% {
    background: {$css['main_color']};
    opacity: .5;
  }
  50% {
   background: {$css['second_color']};
   opacity: .1;
  }
}

@keyframes stretch {
  0%,
  100% {
    transform: scaleY(1);
    background: {$css['main_color']};
  }
  16.67% {
    transform: scaleY(3);
  }
  33.33% {
    transform: scaleY(1);
  }
  50% {
    transform: scaleY(3);
    background: {$css['second_color']};
  }
  66.67% {
    transform: scaleY(1);
  }
  83.34% {
    transform: scaleY(3);
  }
}

";





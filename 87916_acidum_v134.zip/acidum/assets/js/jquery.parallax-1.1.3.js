/*
Plugin: jQuery Parallax
Version 1.1.3
Author: Ian Lunn
Twitter: @IanLunn
Author URL: http://www.ianlunn.co.uk/
Plugin URL: http://www.ianlunn.co.uk/plugins/jquery-parallax/

Dual licensed under the MIT and GPL licenses:
http://www.opensource.org/licenses/mit-license.php
http://www.gnu.org/licenses/gpl.html
*/
!function(n){var t=n(window),o=t.height();t.resize(function(){o=t.height()}),n.fn.parallax=function(e,i,l){function r(){var l=t.scrollTop();h.each(function(){var t=n(this),r=t.offset().top,f=u(t);console.log(f),r+f<l||r>l+o||h.css("backgroundPosition",e+" "+Math.round((c-l)*i)+"px")})}var u,c,h=n(this);h.each(function(){c=h.offset().top}),u=l?function(n){return n.outerHeight(!0)}:function(n){return n.height()},(arguments.length<1||null===e)&&(e="50%"),(arguments.length<2||null===i)&&(i=.1),(arguments.length<3||null===l)&&(l=!0),t.bind("scroll",r).resize(r),r()}}(jQuery);
<?php
/**
 * The blog template file
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 */

$acidum_sidebar_hidden = false;
$acidum_layout = '';
if ( function_exists( 'fw_get_db_settings_option' ) ) {

	$acidum_layout = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'blog-layout' );
	if ( empty($acidum_layout) ) $acidum_layout = fw_get_db_settings_option( 'blog_layout' );
	if ($acidum_layout == 'three-cols') {

		$acidum_sidebar_hidden = true;
	}
}

get_header(); ?>
<div class="inner-page margin-default">
	<?php if ( !$acidum_sidebar_hidden ): ?><div class="row"><?php endif; ?>
        <div class="<?php if ( !$acidum_sidebar_hidden ): ?> col-lg-8 col-md-8<?php endif; ?>">
            <div class="blog blog-block layout-<?php echo esc_attr($acidum_layout); ?>">
				<?php

				if ( $wp_query->have_posts() ) :

	            	echo '<div class="row">';
					while ( $wp_query->have_posts() ) : the_post();

						// Showing classic blog without framework
						if ( !function_exists( 'fw_get_db_settings_option' ) ) {

							get_template_part( 'tmpl/content', get_post_format() );
						}
							else {

							set_query_var( 'acidum_layout', $acidum_layout );

							if ($acidum_layout == 'three-cols') {

								get_template_part( 'tmpl/content-three-cols', get_post_format() );
							}
								else
							if ($acidum_layout == 'two-cols') {

								get_template_part( 'tmpl/content-two-cols', get_post_format() );
							}
								else {

								get_template_part( 'tmpl/content', get_post_format() );
							}
						}

					endwhile;
					echo '</div>';
				else :
					// If no content, include the "No posts found" template.
					get_template_part( 'tmpl/content', 'none' );

				endif;

				?>
				<?php
				if ( have_posts() ) {

					acidum_paging_nav();
				}
	            ?>
	        </div>
	    </div>
	    <?php if ( !$acidum_sidebar_hidden ) :?>
            <?php
            	get_sidebar();
            ?>
		<?php endif; ?>
	<?php if ( !$acidum_sidebar_hidden ): ?></div><?php endif; ?>
</div>
<?php

get_footer();

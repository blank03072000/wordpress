<?php
/**
 * Template Name: Team
 */

get_template_part( 'archive-team' );


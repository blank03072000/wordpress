<?php
/**
 * Template Name: Faq Page
 */

get_template_part( 'archive-faq' );


<?php
/**
 * The Template for gallery inner
 */

get_header();

if ( function_exists( 'fw' ) ):

	$acidum_list = fw_get_db_post_option( get_the_ID(), 'photos' );

?>
<div class=" margin-default">
	<div class="gallery-page gallery-inner">
		<div class="container">
			<div class="row">
				<?php foreach ( $acidum_list as $item ) : ?>
				<div class="col-lg-4 col-md-4 col-sm-6 col-ms-6">
					<div class="item matchHeight">
						<?php
							$caption = fw_get_db_settings_option( 'gallery_caption' );

							if ( $caption != 'disabled '){

								$item_post = get_post( $item['attachment_id'] );

								if ( !empty( $item_post->post_excerpt ) ) {

									$caption_text = $item_post->post_excerpt;
								}
							}
						?>					
						<a href="<?php echo esc_url( $item['url'] ); ?>" class="swipebox photo"<?php if (!empty($caption_text)) echo ' title="'.esc_html($caption_text).'"'; ?>>
							<?php echo wp_get_attachment_image( $item['attachment_id'], 'acidum-gallery' ); ?><span class="fa fa-search"></span>
							<?php
								if ( $caption == 'overlay' AND !empty($caption_text) ) {

									echo '<h6 class="overlay color-main">'.esc_html($caption_text) .'</h6>';
								}
							?>							
						</a>
						<?php
							if ( $caption == 'title' AND !empty($caption_text) ) {

								echo '<h6 class="header color-main">'.esc_html($caption_text) .'</h6>';
							}
						?>
					</div>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>
<?php

endif;

get_footer();


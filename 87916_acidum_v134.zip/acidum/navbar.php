<?php
/**
 * Navigation Bar
 */

$navbar_affix = '';
$navbar_layout = 'default';
$social_mobile = 'disabled';
if ( function_exists( 'FW' ) ) {

	$navbar_layout = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'navbar-layout' );
	if ( empty($basket_icon) ) $basket_icon = fw_get_db_settings_option( 'basket-icon' );
	$navbar_affix = fw_get_db_settings_option( 'navbar-affix' );
	if ($navbar_affix == 'affix') $navbar_affix = 'affix'; else $navbar_affix = '';

	$social_mobile = fw_get_db_settings_option( 'social-icons-mobile' );
}

$navbar_class = ' ';
if ( !empty($navbar_layout) AND $navbar_layout == 'fixed-left' ) $navbar_class = ' navbar-fixed-left';

if ( empty($basket_icon) ) $basket_icon = 'mobile';

if ( $navbar_layout != 'disabled' ):


?>
<div id="nav-wrapper">
	<nav data-spy="<?php echo esc_attr($navbar_affix); ?>"" data-offset-top="0" class="navbar <?php echo esc_attr($navbar_class);?>">
		<div class="container">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed">
					<span class="sr-only"><?php echo esc_html__( 'Toggle navigation', 'acidum' ); ?></span>
					<span class="icon-bar top-bar"></span>
					<span class="icon-bar middle-bar"></span>
					<span class="icon-bar bottom-bar"></span>
				</button>
				<a class="logo <?php if ( !empty($navbar_layout) AND $navbar_layout == 'white' ) echo 'hidden-lg'; ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php
					if ( function_exists( 'FW' ) ) {

						$acidum_logo = fw_get_db_post_option( $wp_query->get_queried_object_id(), 'logo-page' );
						if ( empty( $acidum_logo ) ) $acidum_logo = fw_get_db_settings_option( 'logo_white' );	

						if ( !empty( $acidum_logo ) ) {

							echo wp_get_attachment_image( $acidum_logo['attachment_id'], 'full' );
						}									
					}

					if ( empty( $acidum_logo ) ) {

						echo '<img src="' . esc_attr( get_template_directory_uri() . '/assets/images/logo.png' ) . '" alt="' . esc_attr( get_bloginfo( 'title' ) ) . '">';
					}
					?>
				</a>
			</div>
			<?php if( acidum_is_wc('wc_active') AND $basket_icon != 'disabled' ) : ?>
				<?php 
					$basket_icon_class = ' hidden-lg hidden-xl';
					if ($navbar_layout == 'fixed-left') $basket_icon_class = ' ';
				?>
				<div class="pull-right  nav-right<?php echo esc_attr( $basket_icon_class ); ?>">			
					<div id="top-search" class="top-search">
						<a href="#" id="top-search-ico" class="top-search-ico fa fa-search" aria-hidden="true"></a>
						<input placeholder="<?php esc_html__( 'Search', 'acidum' ); ?>" value="" type="text">
					</div>				
					<a href="<?php echo wc_get_cart_url(); ?>" class="shop_table cart" title="<?php echo esc_html__( 'View your shopping cart', 'acidum' ); ?>">
						<i class="fa fa-shopping-cart" aria-hidden="true"></i>
						<span class="cart-contents header-cart-count count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
					</a>					
				</div>
			<?php endif; ?>							
			<div id="navbar" class="navbar-collapse collapse">
				<div class="toggle-wrap">
					<button type="button" class="navbar-toggle collapsed">
						<span class="sr-only"><?php echo esc_html__( 'Toggle navigation', 'acidum' ); ?></span>
						<span class="icon-bar top-bar"></span>
						<span class="icon-bar middle-bar"></span>
						<span class="icon-bar bottom-bar"></span>
					</button>							
					<div class="clearfix"></div>
				</div>
				<?php
					if ( $social_mobile == 'before' ) acidum_social_icons();
				?>
				<?php
					wp_nav_menu(array(
						'theme_location'	=> 'primary',
						'menu_class' => 'nav navbar-nav',
						'container'	=> 'ul',
						'link_before' => '<span>',     
						'link_after'  => '</span>'							
					));
				?>		
				<div class="nav-mob">
					<ul class="nav navbar-nav">
					<?php if( acidum_is_wc('wc_active') ) : ?>
						<li>
							<a href="<?php echo wc_get_cart_url(); ?>" class="shop_table cart-mob" title="<?php echo esc_html__( 'View your shopping cart', 'acidum' ); ?>">
								<span class="cart-contents header-cart-count count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
								<i class="fa fa-shopping-cart" aria-hidden="true"></i>
								<span class="name"><?php echo esc_html__( 'Cart', 'acidum' ); ?></span>
							</a>
						</li>
					<?php endif; ?>
					</ul>
				</div>
				<?php
					if ( $social_mobile == 'after' ) acidum_social_icons();
				?>					
			</div>
		</div>
	</nav>
</div>
<?php

endif;


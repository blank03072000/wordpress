<?php
/**
 * The template for displaying Search Results pages
 */

get_template_part( 'blog' );


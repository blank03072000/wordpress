<?php
/**
 * The sidebar containing the main widget area
 *
 */

if ( acidum_is_wc('woocommerce') || acidum_is_wc('shop') || acidum_is_wc('product') ) : ?>
	<?php if ( is_active_sidebar( 'sidebar-wc' ) ): ?>
	<div class="col-lg-4 col-md-4 col-lg-pull-8 col-md-pull-8">
		<div id="content-sidebar" class="content-sidebar woocommerce-sidebar widget-area" role="complementary">
			<?php dynamic_sidebar( 'sidebar-wc' ); ?>
		</div>
	</div>
	<?php endif; ?>
	</div></div>
<?php elseif ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div class="col-lg-4 col-md-4">
		<div id="content-sidebar" class="content-sidebar widget-area" role="complementary">
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>
	</div>
<?php endif; ?>
